#!/bin/sh
xterm -title "ADD $*" -fn 12x24 -xrm 'XTerm*.sunKeyboard:false' -e add $*
